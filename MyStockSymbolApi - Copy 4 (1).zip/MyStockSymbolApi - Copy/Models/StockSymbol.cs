namespace MyStockSymbolApi.Models
{
    public class StockSymbol
    {
        public string Symbol { get; set; }
        public string Description { get; set; }
    }
}
